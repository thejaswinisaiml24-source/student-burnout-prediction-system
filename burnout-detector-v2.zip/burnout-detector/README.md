# 🎓 BurnoutSense — Early Detection of Student Burnout

> An AI-powered system that predicts student burnout risk from academic and lifestyle data, with SHAP explainability and personalized intervention recommendations.

---

## 📋 Table of Contents

- [Overview](#overview)
- [System Architecture](#system-architecture)
- [ML Pipeline](#ml-pipeline)
- [Features](#features)
- [Quick Start](#quick-start)
- [API Reference](#api-reference)
- [Project Structure](#project-structure)
- [Tech Stack](#tech-stack)

---

## Overview

BurnoutSense uses a trained XGBoost classifier with SHAP explainability to:

1. **Predict burnout risk** (score 0–100, levels: Low / Medium / High)
2. **Identify top contributing factors** for each individual prediction
3. **Generate actionable recommendations** mapped to specific risk signals
4. **Visualize global feature importance** from SHAP values

---

## System Architecture

```
Student Input (React UI)
        │
        ▼
FastAPI Backend (/predict)
        │
        ├─► Feature Engineering
        │     ├── Performance Drop Rate
        │     ├── Academic Pressure Index
        │     └── Lifestyle Imbalance Score
        │
        ├─► XGBoost Model (tuned via GridSearchCV)
        │     └── Multi-class: Low / Medium / High
        │
        ├─► SHAP TreeExplainer
        │     └── Top 3 instance-level feature contributions
        │
        └─► Response: Score + Risk Level + Factors + Recommendations
```

---

## ML Pipeline

### Dataset
- **1,200 synthetic student records** with realistic feature distributions
- **12 input features** (9 raw + 3 derived)
- **Labels**: Low (0–33), Medium (34–66), High (67–100) burnout

### Features

| Category | Feature | Range |
|---|---|---|
| Academic | Study hours/day | 0–12 hrs |
| Academic | Assignment delay | 0–14 days |
| Academic | Attendance % | 30–100% |
| Academic | Marks trend | -30 to +30 pts |
| Lifestyle | Sleep hours | 2–10 hrs |
| Lifestyle | Screen time | 0–12 hrs |
| Lifestyle | Break frequency | 0–8/day |
| Psychological | Stress level | 1–10 |
| Psychological | Mood score | 1–10 |
| **Derived** | Performance Drop Rate | 0–100 |
| **Derived** | Academic Pressure Index | 0–100 |
| **Derived** | Lifestyle Imbalance Score | 0–100 |

### Models Trained

| Model | Role |
|---|---|
| Logistic Regression | Baseline |
| Random Forest | Comparison |
| **XGBoost** | **Primary (GridSearchCV tuned)** |

### Evaluation Metrics
- Accuracy, Precision, Recall, F1 Score (weighted)
- Results saved to `backend/model_results.json`

### Explainability
- **SHAP TreeExplainer** for instance-level explanations
- Top 3 features ranked by absolute SHAP value per prediction
- Global importance via mean absolute SHAP across all classes

---

## Features

### Input Dashboard
- Organized into **Academic / Lifestyle / Psychological** sections
- Slider-based inputs with live value display
- Real-time sidebar preview

### Results Page
- **Animated burnout gauge** (0–100 with needle)
- **Risk level badge** (color-coded: green / amber / red)
- **Probability distribution** bar across all three risk levels
- **Top 3 SHAP factors** with direction (increases/decreases risk)
- **Personalized recommendations** with priority levels

### Model Insights
- **Global SHAP feature importance** horizontal bar chart
- Togglable via "View Model Insights" button

---

## Quick Start

### Prerequisites
- Python 3.9+
- Node.js 18+

### Option 1: Automated (Linux/macOS)
```bash
chmod +x start.sh
./start.sh
```

### Option 2: Automated (Windows)
```
Double-click start.bat
```

### Option 3: Manual

**Backend:**
```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Train the model (required first time)
python ml_pipeline.py

# Start the API server
uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

**Frontend:**
```bash
cd frontend
npm install
npm start
```

**Access:**
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- Swagger Docs: http://localhost:8000/docs

---

## API Reference

### `POST /predict`

Predict burnout risk for a student.

**Request Body:**
```json
{
  "study_hours": 3.5,
  "assignment_delay": 4,
  "attendance_pct": 72,
  "marks_trend": -10,
  "sleep_hours": 5.5,
  "screen_time": 6,
  "break_frequency": 1,
  "stress_level": 8,
  "mood_score": 4
}
```

**Response:**
```json
{
  "burnout_score": 74.2,
  "risk_level": "High",
  "risk_color": "#ef4444",
  "top_factors": [
    {
      "feature": "Stress Level",
      "feature_key": "stress_level",
      "shap_value": 0.421,
      "direction": "increases",
      "impact": "High"
    }
  ],
  "recommendations": [
    {
      "factor": "Very High Stress",
      "suggestion": "Practice daily mindfulness or breathing exercises...",
      "priority": "high"
    }
  ],
  "probabilities": {
    "low": 0.04,
    "medium": 0.12,
    "high": 0.84
  }
}
```

### `GET /feature-importance`
Returns global SHAP feature importance scores.

### `GET /model-metrics`
Returns training metrics for all three models.

### `GET /health`
Returns API and model health status.

---

## Project Structure

```
burnout-detector/
├── backend/
│   ├── ml_pipeline.py        # Dataset generation, training, SHAP
│   ├── app.py                # FastAPI server
│   ├── requirements.txt      # Python dependencies
│   ├── model.pkl             # Trained XGBoost (generated)
│   ├── scaler.pkl            # StandardScaler (generated)
│   ├── explainer.pkl         # SHAP explainer (generated)
│   ├── feature_cols.json     # Feature column names (generated)
│   ├── feature_importance.json  # Global SHAP importance (generated)
│   └── model_results.json    # Evaluation metrics (generated)
│
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── App.js            # Root component + routing
│   │   ├── index.js          # React entry point
│   │   ├── index.css         # Global styles + design tokens
│   │   ├── pages/
│   │   │   ├── LandingPage.js / .css
│   │   │   ├── InputDashboard.js / .css
│   │   │   └── ResultsPage.js / .css
│   │   └── utils/
│   │       └── api.js        # API client
│   └── package.json
│
├── start.sh                  # Linux/macOS startup script
├── start.bat                 # Windows startup script
└── README.md
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Recharts, CSS Variables |
| Backend | FastAPI, Uvicorn, Pydantic |
| ML Models | Scikit-learn, XGBoost |
| Explainability | SHAP (TreeExplainer) |
| Tuning | GridSearchCV |
| Styling | Custom CSS with design tokens |

---

## Notes

- The model is trained on **synthetic data** generated to reflect realistic student patterns. For production, replace with real institutional data.
- The `ml_pipeline.py` script must be run **before** starting the backend for the first time to generate `model.pkl` and related artifacts.
- Model artifacts are saved to the `backend/` directory and loaded on server startup.
