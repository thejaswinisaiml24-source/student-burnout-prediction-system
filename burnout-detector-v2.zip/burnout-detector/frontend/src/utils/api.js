const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';

export async function predictBurnout(formData) {
  const response = await fetch(`${API_BASE}/predict`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(formData),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.detail || 'Prediction failed');
  }

  return response.json();
}

export async function getFeatureImportance() {
  const response = await fetch(`${API_BASE}/feature-importance`);
  if (!response.ok) throw new Error('Failed to fetch feature importance');
  return response.json();
}

export async function getModelMetrics() {
  const response = await fetch(`${API_BASE}/model-metrics`);
  if (!response.ok) throw new Error('Failed to fetch metrics');
  return response.json();
}

export async function checkHealth() {
  const response = await fetch(`${API_BASE}/health`);
  return response.json();
}
