import React, { useState, useEffect } from 'react';
import LandingPage    from './pages/LandingPage';
import InputDashboard from './pages/InputDashboard';
import ResultsPage    from './pages/ResultsPage';

export default function App() {
  const [page,      setPage]      = useState('landing');
  const [results,   setResults]   = useState(null);
  const [inputData, setInputData] = useState(null);
  const [theme,     setTheme]     = useState('dark');

  // Apply theme to <html> so CSS [data-theme] selectors work
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(t => t === 'dark' ? 'light' : 'dark');

  const handleStart = () => setPage('input');

  const handleResults = (data, inputs) => {
    setResults(data);
    setInputData(inputs);
    setPage('results');
  };

  const handleReset = () => {
    setPage('input');
    setResults(null);
    setInputData(null);
  };

  return (
    <div className="page-wrapper">
      <div className="bg-mesh" />
      {page === 'landing' &&
        <LandingPage onStart={handleStart} theme={theme} toggleTheme={toggleTheme} />}
      {page === 'input' &&
        <InputDashboard onSubmit={handleResults} theme={theme} toggleTheme={toggleTheme} />}
      {page === 'results' &&
        <ResultsPage
          results={results}
          inputData={inputData}
          onReset={handleReset}
          theme={theme}
          toggleTheme={toggleTheme}
        />}
    </div>
  );
}
