import React, { useEffect, useState } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
} from 'recharts';
import { getFeatureImportance, getModelMetrics } from '../utils/api';
import './ResultsPage.css';

/* ── helpers ──────────────────────────────────────────────────────────────── */
function pct(v) { return `${(v * 100).toFixed(1)}%`; }
function fmt(v) { return (v * 100).toFixed(1); }
const PRIORITY_COLOR = { high: '#ef4444', medium: '#f59e0b', low: '#22c55e' };

/* ── Animated counter ──────────────────────────────────────────────────────── */
function CountUp({ to, duration = 1200 }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start = 0; const step = to / (duration / 16);
    const t = setInterval(() => {
      start += step;
      if (start >= to) { setVal(to); clearInterval(t); }
      else setVal(Math.round(start));
    }, 16);
    return () => clearInterval(t);
  }, [to, duration]);
  return <>{val}</>;
}

/* ── Semi-circular gauge ────────────────────────────────────────────────────── */
function Gauge({ score }) {
  const color = score <= 33 ? '#22c55e' : score <= 66 ? '#f59e0b' : '#ef4444';
  const label = score <= 33 ? 'Low Risk' : score <= 66 ? 'Medium Risk' : 'High Risk';
  // Arc: total length ≈ π * r = π * 80 ≈ 251.3
  const ARC = 251.3;
  const filled = (score / 100) * ARC;
  const rotation = (score / 100) * 180 - 90;

  return (
    <div className="gauge-wrap">
      <svg viewBox="0 0 200 115" className="gauge-svg">
        <defs>
          <linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%"   stopColor="#22c55e" />
            <stop offset="50%"  stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#ef4444" />
          </linearGradient>
        </defs>
        {/* Track */}
        <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="var(--bg-3)" strokeWidth="14" strokeLinecap="round" />
        {/* Fill */}
        <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="url(#g1)" strokeWidth="14" strokeLinecap="round"
          strokeDasharray={ARC} strokeDashoffset={ARC - filled}
          style={{ transition: 'stroke-dashoffset 1.3s cubic-bezier(.4,0,.2,1)' }} />
        {/* Needle */}
        <g transform={`translate(100,100) rotate(${rotation})`} style={{ transition: 'transform 1.3s cubic-bezier(.4,0,.2,1)' }}>
          <line x1="0" y1="4" x2="0" y2="-68" stroke={color} strokeWidth="3" strokeLinecap="round" />
          <circle cx="0" cy="0" r="6" fill={color} />
        </g>
        {/* Tick labels */}
        {[[0,20,104],[33,55,30],[66,146,20],[100,180,104]].map(([v,x,y],i)=>(
          <text key={i} x={x} y={y} textAnchor="middle" fontSize="7"
            fill="var(--text-3)" fontFamily="var(--mono)">{v}</text>
        ))}
      </svg>
      <div className="gauge-score" style={{ color }}>
        <CountUp to={score} /><span className="gauge-den">/100</span>
      </div>
      <div className="gauge-label" style={{ color, borderColor: color + '44', background: color + '18' }}>
        {label}
      </div>
    </div>
  );
}

/* ── Model metrics card ────────────────────────────────────────────────────── */
const MODEL_META = {
  logistic_regression: { label: 'Logistic Regression', short: 'LR',  color: '#64748b' },
  random_forest:       { label: 'Random Forest',        short: 'RF',  color: '#3b82f6' },
  xgboost:             { label: 'XGBoost (final)',       short: 'XGB', color: '#8b5cf6' },
};
const METRICS_ORDER = ['accuracy','precision','recall','f1'];

function ModelMetricsSection({ metrics }) {
  return (
    <div className="metrics-section">
      <span className="section-tag">Model Comparison</span>
      <h2 className="card-title">Training Evaluation Metrics</h2>
      <p className="card-desc">
        All three models were evaluated on a held-out 20% test set. XGBoost was selected as the final model.
      </p>

      <div className="metrics-grid">
        {Object.entries(MODEL_META).map(([key, meta]) => {
          const m = metrics[key];
          if (!m) return null;
          const isWinner = key === 'xgboost';
          return (
            <div key={key} className={`metric-model-card ${isWinner ? 'metric-model-card--winner' : ''}`}>
              <div className="mmc-header">
                <span className="mmc-label" style={{ color: meta.color }}>{meta.label}</span>
                {isWinner && <span className="winner-badge">✓ Selected</span>}
              </div>
              <div className="mmc-metrics">
                {METRICS_ORDER.map(metric => (
                  <div key={metric} className="mmc-metric">
                    <span className="mmc-metric-name">{metric.charAt(0).toUpperCase() + metric.slice(1)}</span>
                    <span className="mmc-metric-val" style={{ color: isWinner ? meta.color : 'var(--text-1)' }}>
                      {(m[metric] * 100).toFixed(1)}%
                    </span>
                    <div className="mmc-bar-track">
                      <div className="mmc-bar-fill"
                        style={{ width: `${m[metric] * 100}%`, background: meta.color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
              {key === 'xgboost' && m.best_params && (
                <div className="mmc-params">
                  <span className="mmc-params-label">Best params (GridSearchCV):</span>
                  {Object.entries(m.best_params).map(([k,v]) => (
                    <span key={k} className="param-chip">{k}: {v}</span>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── Custom tooltip ─────────────────────────────────────────────────────────── */
const ChartTip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="chart-tip">
      <p className="ct-label">{label}</p>
      <p className="ct-val">{payload[0].value.toFixed(4)}</p>
    </div>
  );
};

/* ── Main Results page ──────────────────────────────────────────────────────── */
export default function ResultsPage({ results, inputData, onReset, theme, toggleTheme }) {
  const [fiData,  setFiData]  = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [tab,     setTab]     = useState('overview'); // 'overview' | 'model' | 'insights'

  useEffect(() => {
    getFeatureImportance().then(d => {
      const arr = Object.entries(d.feature_importance)
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value).slice(0, 12);
      setFiData(arr);
    }).catch(() => {});
    getModelMetrics().then(d => setMetrics(d.metrics)).catch(() => {});
  }, []);

  const {
    burnout_score, risk_level, risk_color,
    top_factors, all_shap_factors,
    recommendations, probabilities,
    derived_features, input_summary,
  } = results;

  // Radar data from input summary
  const radarData = [
    { subject: 'Stress',     val: (input_summary.stress_level / 10) * 100 },
    { subject: 'Sleep',      val: (1 - (input_summary.sleep_hours - 2) / 8) * 100 },
    { subject: 'Screen',     val: (input_summary.screen_time / 12) * 100 },
    { subject: 'Attend.',    val: 100 - input_summary.attendance_pct },
    { subject: 'Delay',      val: (input_summary.assignment_delay / 14) * 100 },
    { subject: 'Mood ↓',     val: ((10 - input_summary.mood_score) / 9) * 100 },
  ];

  return (
    <div className="rp">
      {/* Header */}
      <div className="rp-header">
        <div className="nav-brand">
          <span className="nav-logo">◈</span>
          <span className="nav-name">BurnoutSense</span>
        </div>
        <div className="rp-header-right">
          <div className="tab-row">
            {[['overview','Overview'],['model','Model Metrics'],['insights','Feature Insights']].map(([k,l]) => (
              <button key={k} className={`tab-btn ${tab === k ? 'tab-btn--active' : ''}`} onClick={() => setTab(k)}>{l}</button>
            ))}
          </div>
          <button className="theme-toggle" onClick={toggleTheme}>{theme === 'dark' ? '☀️' : '🌙'}</button>
        </div>
      </div>

      {/* ══ OVERVIEW TAB ═══════════════════════════════════════════════════════ */}
      {tab === 'overview' && (
        <div className="rp-grid anim-fade-up">
          {/* Left column */}
          <div className="rp-left">
            {/* Score card */}
            <div className="card score-card">
              <span className="section-tag">Burnout Score</span>
              <Gauge score={burnout_score} />

              {/* Probability bars */}
              <div className="prob-section">
                <p className="prob-title">Risk Distribution</p>
                {[
                  { k: 'low',    label: 'Low',    color: '#22c55e' },
                  { k: 'medium', label: 'Medium', color: '#f59e0b' },
                  { k: 'high',   label: 'High',   color: '#ef4444' },
                ].map(item => (
                  <div key={item.k} className="prob-row">
                    <span className="prob-label" style={{ color: item.color }}>{item.label}</span>
                    <div className="prob-track">
                      <div className="prob-fill"
                        style={{ width: pct(probabilities[item.k]), background: item.color }} />
                    </div>
                    <span className="prob-pct">{fmt(probabilities[item.k])}%</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Derived features */}
            <div className="card derived-card">
              <span className="section-tag">Computed Signals</span>
              <h3 className="card-title-sm">Derived Feature Values</h3>
              {[
                { k: 'performance_drop_rate',    l: 'Performance Drop Rate'    },
                { k: 'academic_pressure_index',  l: 'Academic Pressure Index'  },
                { k: 'lifestyle_imbalance_score',l: 'Lifestyle Imbalance Score' },
              ].map(({ k, l }) => {
                const v = derived_features[k];
                const col = v > 66 ? '#ef4444' : v > 33 ? '#f59e0b' : '#22c55e';
                return (
                  <div key={k} className="dv-row">
                    <div className="dv-top">
                      <span className="dv-label">{l}</span>
                      <span className="dv-val" style={{ color: col }}>{v.toFixed(1)}</span>
                    </div>
                    <div className="dv-track">
                      <div className="dv-fill" style={{ width: `${v}%`, background: col }} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Radar */}
            <div className="card radar-card">
              <span className="section-tag">Risk Profile</span>
              <h3 className="card-title-sm">Multi-Dimension View</h3>
              <ResponsiveContainer width="100%" height={210}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="var(--border)" />
                  <PolarAngleAxis dataKey="subject"
                    tick={{ fill: 'var(--text-2)', fontSize: 11, fontFamily: 'var(--font)' }} />
                  <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar dataKey="val" stroke={risk_color}
                    fill={risk_color} fillOpacity={0.18} strokeWidth={2} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Right column */}
          <div className="rp-right">
            {/* SHAP top factors */}
            <div className="card factors-card">
              <span className="section-tag">SHAP Analysis</span>
              <h2 className="card-title">Top Contributing Factors</h2>
              <p className="card-desc">
                Features with the highest per-instance SHAP values for your predicted risk class.
                Each value is relative to this specific prediction.
              </p>
              <div className="factors-list">
                {top_factors.map((f, i) => {
                  const isNeg = f.direction === 'decreases';
                  const barColor = isNeg ? '#22c55e' : '#ef4444';
                  const relPct   = Math.round(f.relative_imp * 100);
                  return (
                    <div key={i} className="factor-row" style={{ animationDelay: `${i * 0.07}s` }}>
                      <div className="fr-rank">{i + 1}</div>
                      <div className="fr-body">
                        <div className="fr-name">{f.feature}</div>
                        <div className="fr-meta">
                          <span className={`fr-dir ${isNeg ? 'fr-dir--neg' : 'fr-dir--pos'}`}>
                            {isNeg ? '↓ Decreases' : '↑ Increases'} burnout risk
                          </span>
                          <span className="fr-actual">
                            Current: <b>{f.actual_value}</b>
                          </span>
                        </div>
                        <div className="fr-bar-track">
                          <div className="fr-bar-fill" style={{ width: `${relPct}%`, background: barColor }} />
                        </div>
                      </div>
                      <div className="fr-impact" style={{
                        color: f.impact === 'High' ? '#ef4444' : f.impact === 'Medium' ? '#f59e0b' : '#22c55e'
                      }}>{f.impact}</div>
                    </div>
                  );
                })}
              </div>

              {/* All SHAP factors mini table */}
              <details className="shap-all">
                <summary className="shap-all-toggle">Show all 12 SHAP values</summary>
                <div className="shap-table">
                  <div className="shap-row shap-row--head">
                    <span>Feature</span><span>SHAP</span><span>Direction</span><span>Actual Value</span>
                  </div>
                  {all_shap_factors.map((f, i) => (
                    <div key={i} className="shap-row">
                      <span className="st-feature">{f.feature}</span>
                      <span className="st-shap" style={{ fontFamily: 'var(--mono)', color: f.direction === 'increases' ? '#ef4444' : '#22c55e' }}>
                        {f.shap_value > 0 ? '+' : ''}{f.shap_value.toFixed(4)}
                      </span>
                      <span className={`st-dir ${f.direction === 'increases' ? 'st-dir--up' : 'st-dir--dn'}`}>
                        {f.direction === 'increases' ? '↑' : '↓'}
                      </span>
                      <span className="st-val" style={{ fontFamily: 'var(--mono)' }}>{f.actual_value}</span>
                    </div>
                  ))}
                </div>
              </details>
            </div>

            {/* Recommendations */}
            <div className="card recs-card">
              <span className="section-tag">Interventions</span>
              <h2 className="card-title">Personalised Recommendations</h2>
              <p className="card-desc">
                Evidence-based strategies mapped to your specific risk indicators.
                High-priority items need immediate attention.
              </p>
              <div className="recs-list">
                {recommendations.map((r, i) => {
                  const pc = PRIORITY_COLOR[r.priority];
                  return (
                    <div key={i} className="rec-row" style={{ animationDelay: `${i * 0.06}s` }}>
                      <div className="rec-accent" style={{ background: pc }} />
                      <div className="rec-body">
                        <div className="rec-top">
                          <span className="rec-factor">{r.factor}</span>
                          <span className="rec-badge"
                            style={{ color: pc, background: pc + '18', borderColor: pc + '33' }}>
                            {r.priority}
                          </span>
                        </div>
                        <p className="rec-text">{r.suggestion}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══ MODEL METRICS TAB ══════════════════════════════════════════════════ */}
      {tab === 'model' && (
        <div className="tab-content anim-fade-up">
          {metrics
            ? <div className="card"><ModelMetricsSection metrics={metrics} /></div>
            : <div className="card loading-card">Loading model metrics…</div>
          }
        </div>
      )}

      {/* ══ INSIGHTS TAB ═══════════════════════════════════════════════════════ */}
      {tab === 'insights' && (
        <div className="tab-content anim-fade-up">
          <div className="card">
            <span className="section-tag">Global Feature Importance</span>
            <h2 className="card-title">SHAP Feature Importance (Global)</h2>
            <p className="card-desc">
              Mean absolute SHAP value across all test samples and all risk classes.
              Higher = stronger overall influence on predictions.
            </p>
            {fiData ? (
              <div className="fi-chart-wrap">
                <ResponsiveContainer width="100%" height={380}>
                  <BarChart data={fiData} layout="vertical"
                    margin={{ top: 0, right: 50, left: 200, bottom: 0 }}>
                    <XAxis type="number"
                      tick={{ fill: 'var(--text-2)', fontSize: 11, fontFamily: 'var(--mono)' }}
                      axisLine={false} tickLine={false} />
                    <YAxis type="category" dataKey="name" width={195}
                      tick={{ fill: 'var(--text-1)', fontSize: 12, fontFamily: 'var(--font)' }}
                      axisLine={false} tickLine={false} />
                    <Tooltip content={<ChartTip />} />
                    <Bar dataKey="value" radius={[0, 6, 6, 0]} barSize={18}>
                      {fiData.map((_, i) => (
                        <Cell key={i}
                          fill={i === 0 ? '#8b5cf6' : i < 3 ? '#6366f1' : i < 6 ? '#3b82f6' : '#64748b'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : <div className="loading-card">Loading feature importance…</div>}

            {/* Per-instance SHAP bar for this prediction */}
            {all_shap_factors && (
              <>
                <div className="divider" />
                <span className="section-tag">Per-Instance SHAP</span>
                <h3 className="card-title">Your Prediction's Feature Contributions</h3>
                <p className="card-desc">
                  SHAP values for <em>this specific input</em> — positive pushes toward High, negative toward Low.
                </p>
                <div className="fi-chart-wrap">
                  <ResponsiveContainer width="100%" height={380}>
                    <BarChart
                      data={[...all_shap_factors].sort((a,b) => b.shap_value - a.shap_value)}
                      layout="vertical"
                      margin={{ top: 0, right: 50, left: 200, bottom: 0 }}
                    >
                      <XAxis type="number"
                        tick={{ fill: 'var(--text-2)', fontSize: 11, fontFamily: 'var(--mono)' }}
                        axisLine={false} tickLine={false} />
                      <YAxis type="category" dataKey="feature" width={195}
                        tick={{ fill: 'var(--text-1)', fontSize: 12, fontFamily: 'var(--font)' }}
                        axisLine={false} tickLine={false} />
                      <Tooltip content={<ChartTip />} />
                      <Bar dataKey="shap_value" radius={[0, 6, 6, 0]} barSize={18}>
                        {[...all_shap_factors]
                          .sort((a,b) => b.shap_value - a.shap_value)
                          .map((f, i) => (
                            <Cell key={i} fill={f.shap_value >= 0 ? '#ef4444' : '#22c55e'} />
                          ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="rp-footer">
        <button className="btn-ghost" onClick={onReset}>← New Analysis</button>
      </div>
    </div>
  );
}
