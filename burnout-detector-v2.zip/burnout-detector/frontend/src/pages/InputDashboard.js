import React, { useState } from 'react';
import { predictBurnout } from '../utils/api';
import './InputDashboard.css';

const DEFAULTS = {
  study_hours: 4, assignment_delay: 2, attendance_pct: 80, marks_trend: 0,
  sleep_hours: 7, screen_time: 4, break_frequency: 3,
  stress_level: 5, mood_score: 6,
};

const SECTIONS = [
  {
    key: 'academic', label: 'Academic', icon: '📚', color: '#3b82f6',
    desc: 'Performance and engagement indicators',
    fields: [
      { key: 'study_hours',      label: 'Study Hours / Day',  min: 0,   max: 12,  step: 0.5, unit: 'hrs',  hint: '0 – 12 hours per day' },
      { key: 'assignment_delay', label: 'Assignment Delay',   min: 0,   max: 14,  step: 0.5, unit: 'days', hint: 'Average days late submitting' },
      { key: 'attendance_pct',   label: 'Attendance',         min: 30,  max: 100, step: 1,   unit: '%',    hint: '30% – 100%' },
      { key: 'marks_trend',      label: 'Marks Trend',        min: -30, max: 30,  step: 1,   unit: 'pts',  hint: 'Change vs last assessment (-30 to +30)' },
    ],
  },
  {
    key: 'lifestyle', label: 'Lifestyle', icon: '🏃', color: '#10b981',
    desc: 'Daily wellness and balance patterns',
    fields: [
      { key: 'sleep_hours',    label: 'Sleep Hours / Night',  min: 2, max: 10, step: 0.5, unit: 'hrs', hint: '2 – 10 hours' },
      { key: 'screen_time',    label: 'Recreational Screen Time', min: 0, max: 12, step: 0.5, unit: 'hrs', hint: 'Non-study screen usage per day' },
      { key: 'break_frequency',label: 'Study Breaks / Day',   min: 0, max: 8,  step: 1,   unit: 'x',   hint: 'Short breaks during study sessions' },
    ],
  },
  {
    key: 'psychological', label: 'Psychological', icon: '🧠', color: '#8b5cf6',
    desc: 'Self-reported mental and emotional state',
    fields: [
      { key: 'stress_level', label: 'Stress Level', min: 1, max: 10, step: 1, unit: '/10', hint: '1 = very calm  ·  10 = extremely stressed' },
      { key: 'mood_score',   label: 'Mood Score',   min: 1, max: 10, step: 1, unit: '/10', hint: '1 = very low  ·  10 = excellent' },
    ],
  },
];

function trackStyle(value, min, max, color) {
  const pct = ((value - min) / (max - min)) * 100;
  return { background: `linear-gradient(to right, ${color} ${pct}%, var(--bg-3) ${pct}%)` };
}

function RiskPreview({ values }) {
  const score = Math.round(
    values.stress_level / 10 * 22 +
    (10 - values.mood_score) / 9 * 20 +
    Math.max(0, 8 - values.sleep_hours) / 6 * 14 +
    values.assignment_delay / 14 * 14 +
    (100 - values.attendance_pct) / 70 * 12 +
    values.screen_time / 12 * 10 +
    (12 - values.study_hours) / 12 * 8
  );
  const clamp = Math.min(100, Math.max(0, score));
  const color = clamp <= 33 ? '#22c55e' : clamp <= 66 ? '#f59e0b' : '#ef4444';
  const label = clamp <= 33 ? 'Low' : clamp <= 66 ? 'Medium' : 'High';
  return (
    <div className="risk-preview">
      <p className="rp-title">Live Estimate</p>
      <div className="rp-score" style={{ color }}>{clamp}</div>
      <div className="rp-label" style={{ color, borderColor: color + '44', background: color + '18' }}>{label} Risk</div>
      <div className="rp-bar-track">
        <div className="rp-bar-fill" style={{ width: `${clamp}%`, background: color }} />
      </div>
      <p className="rp-note">Updates as you adjust sliders</p>
    </div>
  );
}

export default function InputDashboard({ onSubmit, theme, toggleTheme }) {
  const [values,  setValues]  = useState(DEFAULTS);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);

  const set = (key, val) => setValues(prev => ({ ...prev, [key]: parseFloat(val) }));

  const submit = async () => {
    setLoading(true); setError(null);
    try {
      const res = await predictBurnout(values);
      onSubmit(res, values);
    } catch (e) {
      setError(e.message || 'Prediction failed. Is the backend running?');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="dash">
      {/* ── Header ── */}
      <div className="dash-header">
        <div className="nav-brand">
          <span className="nav-logo">◈</span>
          <span className="nav-name">BurnoutSense</span>
        </div>
        <div className="dash-header-right">
          <div className="steps">
            <span className="step active">1 · Input</span>
            <span className="step-sep">›</span>
            <span className="step">2 · Analyse</span>
            <span className="step-sep">›</span>
            <span className="step">3 · Results</span>
          </div>
          <button className="theme-toggle" onClick={toggleTheme}>{theme === 'dark' ? '☀️' : '🌙'}</button>
        </div>
      </div>

      {/* ── Body ── */}
      <div className="dash-body">
        {/* Sidebar */}
        <aside className="dash-aside">
          <RiskPreview values={values} />

          <div className="aside-tips">
            <p className="aside-tips-title">Derived Features</p>
            {(() => {
              const pdr  = Math.min(100, Math.max(0, (30 - values.marks_trend) / 60 * 50 + (100 - values.attendance_pct) / 70 * 50));
              const api  = Math.min(100, Math.max(0, values.assignment_delay / 14 * 40 + (12 - values.study_hours) / 12 * 30 + values.stress_level / 10 * 30));
              const lis  = Math.min(100, Math.max(0, Math.max(0, 8 - values.sleep_hours) / 8 * 35 + values.screen_time / 12 * 30 + Math.max(0, 8 - values.break_frequency) / 8 * 35));
              return [
                { l: 'Performance Drop Rate',    v: pdr },
                { l: 'Academic Pressure Index',  v: api },
                { l: 'Lifestyle Imbalance',       v: lis },
              ].map(({ l, v }) => (
                <div key={l} className="derived-row">
                  <span className="dr-label">{l}</span>
                  <div className="dr-bar-track">
                    <div className="dr-bar" style={{ width: `${v}%`, background: v > 66 ? '#ef4444' : v > 33 ? '#f59e0b' : '#22c55e' }} />
                  </div>
                  <span className="dr-val">{Math.round(v)}</span>
                </div>
              ));
            })()}
          </div>
        </aside>

        {/* Form */}
        <main className="dash-form">
          {SECTIONS.map(sec => (
            <section key={sec.key} className="form-sec anim-fade-up">
              <div className="form-sec-hdr">
                <div className="sec-icon">{sec.icon}</div>
                <div>
                  <h2 className="sec-title">{sec.label} Indicators</h2>
                  <p className="sec-desc">{sec.desc}</p>
                </div>
              </div>
              <div className="fields-grid">
                {sec.fields.map(f => (
                  <div key={f.key} className="field-tile">
                    <div className="field-hdr">
                      <label className="input-label">{f.label}</label>
                      <span className="field-val" style={{ color: sec.color }}>
                        {values[f.key]}{f.unit}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={f.min} max={f.max} step={f.step}
                      value={values[f.key]}
                      onChange={e => set(f.key, e.target.value)}
                      style={trackStyle(values[f.key], f.min, f.max, sec.color)}
                    />
                    <p className="input-hint">{f.hint}</p>
                  </div>
                ))}
              </div>
            </section>
          ))}

          {error && (
            <div className="error-box">
              <span>⚠️</span> <span>{error}</span>
            </div>
          )}

          <div className="submit-bar">
            <p className="submit-note">All 9 inputs collected · 3 derived features computed automatically</p>
            <button className="btn-primary" onClick={submit} disabled={loading}>
              {loading
                ? <span className="loading-row"><span className="spinner" /> Analysing…</span>
                : 'Generate Risk Report →'}
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
