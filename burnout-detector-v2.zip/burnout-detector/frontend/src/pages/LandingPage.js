import React, { useEffect, useState } from 'react';
import './LandingPage.css';

const PIPELINE = [
  { num: '01', title: 'Input Data',          desc: '12 academic & lifestyle signals' },
  { num: '02', title: 'Feature Engineering', desc: '3 derived composite indicators' },
  { num: '03', title: 'XGBoost Model',       desc: 'GridSearchCV-tuned classifier' },
  { num: '04', title: 'SHAP Explainer',      desc: 'Per-instance factor ranking' },
  { num: '05', title: 'Risk Report',         desc: 'Score + recommendations' },
];

const CARDS = [
  { icon: '🎯', title: 'Precise Predictions',    body: 'XGBoost trained on 2,000 student profiles with 3 distinct risk classes. Hyperparameter-tuned via 5-fold cross-validation.' },
  { icon: '🔍', title: 'Explainable AI (SHAP)',  body: 'Every prediction shows the top 3 features driving risk — no black box. Built with TreeExplainer for exact Shapley values.' },
  { icon: '💡', title: 'Actionable Guidance',    body: 'Rule-based intervention engine maps each detected risk factor to specific, evidence-backed recommendations.' },
];

export default function LandingPage({ onStart, theme, toggleTheme }) {
  const [vis, setVis] = useState(false);
  useEffect(() => { setTimeout(() => setVis(true), 80); }, []);

  return (
    <div className={`landing ${vis ? 'landing--visible' : ''}`}>
      <nav className="nav">
        <div className="nav-brand">
          <span className="nav-logo">◈</span>
          <span className="nav-name">BurnoutSense</span>
          <span className="nav-pill">ML v2</span>
        </div>
        <button className="theme-toggle" onClick={toggleTheme} title="Toggle theme">
          {theme === 'dark' ? '☀️' : '🌙'}
        </button>
      </nav>

      <section className="hero">
        <div className="hero-eyebrow">
          <span className="live-dot" />&nbsp; AI-Powered Student Wellness
        </div>
        <h1 className="hero-h1">
          Detect Burnout<br />
          <span className="gradient-text">Before It Hits</span>
        </h1>
        <p className="hero-sub">
          Answer 9 quick questions. Our XGBoost model analyses 12 signals and tells you
          exactly where your risk is coming from — with SHAP-backed explanations and
          personalised action plans.
        </p>
        <button className="btn-primary hero-cta" onClick={onStart}>
          Start Free Assessment →
        </button>
        <p className="hero-meta">No login · 2 minutes · Instant results</p>
      </section>

      <section className="stats-row">
        {[
          { v: '2 000+', l: 'Training Profiles' },
          { v: '12',     l: 'Input Signals' },
          { v: '5-fold', l: 'Cross-validation' },
          { v: 'SHAP',   l: 'Explainability' },
        ].map((s, i) => (
          <div key={i} className="stat-tile card" style={{ animationDelay: `${i * 0.07}s` }}>
            <span className="stat-v gradient-text">{s.v}</span>
            <span className="stat-l">{s.l}</span>
          </div>
        ))}
      </section>

      <section className="features-row">
        {CARDS.map((c, i) => (
          <div key={i} className="feat-card card" style={{ animationDelay: `${0.15 + i * 0.08}s` }}>
            <div className="feat-icon">{c.icon}</div>
            <h3 className="feat-title">{c.title}</h3>
            <p className="feat-body">{c.body}</p>
          </div>
        ))}
      </section>

      <section className="pipeline-section">
        <span className="section-tag">ML Pipeline</span>
        <h2 className="pipeline-h2">How It Works</h2>
        <div className="pipeline-row">
          {PIPELINE.map((step, i) => (
            <React.Fragment key={i}>
              <div className="p-step card">
                <div className="p-num gradient-text">{step.num}</div>
                <div className="p-title">{step.title}</div>
                <div className="p-desc">{step.desc}</div>
              </div>
              {i < PIPELINE.length - 1 && <div className="p-arrow">→</div>}
            </React.Fragment>
          ))}
        </div>
      </section>

      <section className="cta-section card">
        <h2>Ready to get your risk score?</h2>
        <p>Fill in your academic and lifestyle data. Results in under 10 seconds.</p>
        <button className="btn-primary" onClick={onStart}>Start Assessment →</button>
      </section>

      <footer className="footer">
        <span>Built with XGBoost · SHAP · FastAPI · React</span>
        <span className="footer-dot">·</span>
        <span>For educational purposes only</span>
      </footer>
    </div>
  );
}
