@echo off
echo.
echo ╔══════════════════════════════════════════════════════╗
echo ║     BurnoutSense - Student Burnout Detection AI      ║
echo ╚══════════════════════════════════════════════════════╝
echo.

cd /d "%~dp0"

REM ---- Backend ----
echo [1/4] Setting up Python virtual environment...
cd backend
if not exist venv (
    python -m venv venv
)
call venv\Scripts\activate.bat

echo [2/4] Installing Python dependencies...
pip install -q -r requirements.txt

if not exist model.pkl (
    echo [3/4] Training ML model ^(~1-2 minutes^)...
    python ml_pipeline.py
) else (
    echo [3/4] Model already trained, skipping...
)

echo [4/4] Starting backend server...
start "BurnoutSense Backend" cmd /k "venv\Scripts\activate && uvicorn app:app --host 0.0.0.0 --port 8000 --reload"
cd ..

REM ---- Frontend ----
echo.
echo Setting up frontend...
cd frontend
if not exist node_modules (
    echo Installing Node dependencies...
    npm install
)
start "BurnoutSense Frontend" cmd /k "npm start"
cd ..

echo.
echo ╔══════════════════════════════════════════════════════╗
echo ║  BurnoutSense is starting up!                        ║
echo ║                                                      ║
echo ║  Frontend: http://localhost:3000                     ║
echo ║  Backend:  http://localhost:8000                     ║
echo ║  API Docs: http://localhost:8000/docs                ║
echo ╚══════════════════════════════════════════════════════╝
echo.
pause
