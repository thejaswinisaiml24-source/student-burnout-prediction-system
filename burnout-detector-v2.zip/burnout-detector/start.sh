#!/bin/bash
# ============================================================
# BurnoutSense - Setup & Run Script
# ============================================================

set -e

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║     BurnoutSense - Student Burnout Detection AI      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
  echo "❌ Python3 not found. Please install Python 3.9+"
  exit 1
fi

# Check Node
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Please install Node.js 18+"
  exit 1
fi

echo "✅ Python3 found: $(python3 --version)"
echo "✅ Node.js found: $(node --version)"
echo ""

# ---- Backend Setup ----
echo "📦 Setting up backend..."
cd backend

# Create virtual env if not exists
if [ ! -d "venv" ]; then
  python3 -m venv venv
  echo "✅ Virtual environment created"
fi

source venv/bin/activate

# Install dependencies
echo "📥 Installing Python dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

# Train model if not exists
if [ ! -f "model.pkl" ]; then
  echo ""
  echo "🤖 Training ML model (this takes ~1-2 minutes)..."
  python3 ml_pipeline.py
  echo "✅ Model training complete"
else
  echo "✅ Trained model found, skipping training"
fi

echo ""
echo "🚀 Starting FastAPI backend on http://localhost:8000"
uvicorn app:app --host 0.0.0.0 --port 8000 --reload &
BACKEND_PID=$!
echo "✅ Backend started (PID: $BACKEND_PID)"

cd ..

# ---- Frontend Setup ----
echo ""
echo "📦 Setting up frontend..."
cd frontend

if [ ! -d "node_modules" ]; then
  echo "📥 Installing Node dependencies..."
  npm install
fi

echo ""
echo "🚀 Starting React frontend on http://localhost:3000"
npm start &
FRONTEND_PID=$!

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  ✅ BurnoutSense is running!                         ║"
echo "║                                                      ║"
echo "║  Frontend: http://localhost:3000                     ║"
echo "║  Backend:  http://localhost:8000                     ║"
echo "║  API Docs: http://localhost:8000/docs                ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "Press Ctrl+C to stop all services."

# Trap Ctrl+C
trap "echo ''; echo 'Stopping services...'; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit 0" SIGINT

wait
