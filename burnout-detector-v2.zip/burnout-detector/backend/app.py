"""
Early Detection of Student Burnout — FastAPI Backend (v2)
Fixes:
  - Burnout score now reflects actual feature values, not just class probabilities
  - SHAP values extracted per-instance using new Explanation API (3-D array)
  - Impact thresholds scaled to actual SHAP magnitude
  - Returns derived feature values so UI can display them
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import numpy as np
import pandas as pd
import pickle
import json
import os
from typing import List, Dict

app = FastAPI(
    title="Student Burnout Detection API",
    description="XGBoost + SHAP burnout predictor",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

MODEL_DIR = os.path.dirname(os.path.abspath(__file__))

# ── Globals ──────────────────────────────────────────────────────────────────
model = scaler = explainer = feature_cols = feature_importance = model_results = None


def load_artifacts():
    global model, scaler, explainer, feature_cols, feature_importance, model_results
    paths = {
        'model':    'model.pkl',
        'scaler':   'scaler.pkl',
        'explainer':'explainer.pkl',
    }
    for name, fname in paths.items():
        p = os.path.join(MODEL_DIR, fname)
        if not os.path.exists(p):
            raise FileNotFoundError(f"{fname} not found — run ml_pipeline.py first")
    with open(os.path.join(MODEL_DIR, 'model.pkl'), 'rb') as f:    model      = pickle.load(f)
    with open(os.path.join(MODEL_DIR, 'scaler.pkl'), 'rb') as f:   scaler     = pickle.load(f)
    with open(os.path.join(MODEL_DIR, 'explainer.pkl'), 'rb') as f: explainer = pickle.load(f)
    with open(os.path.join(MODEL_DIR, 'feature_cols.json')) as f:  feature_cols       = json.load(f)
    with open(os.path.join(MODEL_DIR, 'feature_importance.json')) as f: feature_importance = json.load(f)
    with open(os.path.join(MODEL_DIR, 'model_results.json')) as f: model_results      = json.load(f)
    print("✅ Artifacts loaded")


try:
    load_artifacts()
except Exception as e:
    print(f"⚠️  {e}")


# ── Schema ───────────────────────────────────────────────────────────────────
class StudentInput(BaseModel):
    study_hours:       float = Field(..., ge=0,   le=12)
    assignment_delay:  float = Field(..., ge=0,   le=14)
    attendance_pct:    float = Field(..., ge=0,   le=100)
    marks_trend:       float = Field(..., ge=-30, le=30)
    sleep_hours:       float = Field(..., ge=2,   le=10)
    screen_time:       float = Field(..., ge=0,   le=12)
    break_frequency:   float = Field(..., ge=0,   le=8)
    stress_level:      float = Field(..., ge=1,   le=10)
    mood_score:        float = Field(..., ge=1,   le=10)


class Recommendation(BaseModel):
    factor:     str
    suggestion: str
    priority:   str


class PredictionResponse(BaseModel):
    burnout_score:     float
    risk_level:        str
    risk_color:        str
    top_factors:       List[Dict]
    all_shap_factors:  List[Dict]
    recommendations:   List[Recommendation]
    probabilities:     Dict[str, float]
    derived_features:  Dict[str, float]
    input_summary:     Dict[str, float]


# ── Feature engineering ───────────────────────────────────────────────────────
def engineer_features(inp: StudentInput) -> Dict[str, float]:
    performance_drop_rate = float(np.clip(
        (30 - inp.marks_trend) / 60 * 50 + (100 - inp.attendance_pct) / 70 * 50,
        0, 100
    ))
    academic_pressure_index = float(np.clip(
        inp.assignment_delay / 14 * 40 + (12 - inp.study_hours) / 12 * 30 + inp.stress_level / 10 * 30,
        0, 100
    ))
    lifestyle_imbalance_score = float(np.clip(
        max(0, 8 - inp.sleep_hours) / 8 * 35 + inp.screen_time / 12 * 30 + max(0, 8 - inp.break_frequency) / 8 * 35,
        0, 100
    ))
    return {
        'performance_drop_rate':    round(performance_drop_rate, 2),
        'academic_pressure_index':  round(academic_pressure_index, 2),
        'lifestyle_imbalance_score': round(lifestyle_imbalance_score, 2),
    }


# ── Burnout score from raw features (not just probabilities) ──────────────────
def compute_raw_burnout_score(inp: StudentInput) -> float:
    """
    Deterministic continuous score 0-100 derived from feature values.
    This always varies with input — independent of model class boundaries.
    """
    score = (
        inp.stress_level / 10 * 22 +
        (10 - inp.mood_score) / 9 * 20 +
        max(0, 8 - inp.sleep_hours) / 6 * 14 +
        inp.assignment_delay / 14 * 14 +
        (100 - inp.attendance_pct) / 70 * 12 +
        inp.screen_time / 12 * 10 +
        (12 - inp.study_hours) / 12 * 8
    )
    return float(np.clip(score, 0, 100))


# ── Recommendations ───────────────────────────────────────────────────────────
def get_recommendations(inp: StudentInput) -> List[Recommendation]:
    recs = []

    if inp.sleep_hours < 5.5:
        recs.append(Recommendation(factor="Critical Sleep Deficit",
            suggestion="You are sleeping far below the recommended minimum. Prioritize 7–8 hours immediately — poor sleep amplifies every other burnout risk factor.",
            priority="high"))
    elif inp.sleep_hours < 7:
        recs.append(Recommendation(factor="Insufficient Sleep",
            suggestion="Aim for 7–8 hours nightly. Set a fixed bedtime, avoid caffeine after 3 PM, and dim screens 1 hour before bed.",
            priority="medium"))

    if inp.stress_level >= 8:
        recs.append(Recommendation(factor="Extreme Stress",
            suggestion="Your stress is critically high. Try 4-7-8 breathing daily, consider speaking with a counsellor, and redistribute your workload immediately.",
            priority="high"))
    elif inp.stress_level >= 6:
        recs.append(Recommendation(factor="Elevated Stress",
            suggestion="Incorporate 15 minutes of daily mindfulness or walking. Journaling your worries before bed can reduce anxious rumination.",
            priority="medium"))

    if inp.assignment_delay > 6:
        recs.append(Recommendation(factor="Severe Procrastination",
            suggestion="You are falling significantly behind on deadlines. Use time-blocking: schedule 2-hour focused work sprints and tackle the oldest task first.",
            priority="high"))
    elif inp.assignment_delay > 2:
        recs.append(Recommendation(factor="Assignment Delay",
            suggestion="Create a visual deadline tracker. Break each task into 3 sub-steps — starting is always the hardest part.",
            priority="medium"))

    if inp.mood_score <= 3:
        recs.append(Recommendation(factor="Very Low Mood",
            suggestion="Consistently low mood is a warning sign. Schedule one enjoyable activity per day, stay socially connected, and consider professional support.",
            priority="high"))
    elif inp.mood_score <= 5:
        recs.append(Recommendation(factor="Below-Average Mood",
            suggestion="Boost mood with small wins — complete one task, exercise for 20 minutes, or connect with a friend daily.",
            priority="medium"))

    if inp.attendance_pct < 60:
        recs.append(Recommendation(factor="Critical Attendance",
            suggestion="Missing this many classes creates a compounding catch-up burden. Speak with your academic advisor and identify root causes for absences.",
            priority="high"))
    elif inp.attendance_pct < 75:
        recs.append(Recommendation(factor="Low Attendance",
            suggestion="Regular attendance reduces exam stress. Set phone reminders for each class and find a study partner for accountability.",
            priority="medium"))

    if inp.screen_time > 8:
        recs.append(Recommendation(factor="Excessive Screen Time",
            suggestion="Over 8 hours of screen time heavily impacts sleep and focus. Use app-limit features and replace 2 hours with physical or outdoor activity.",
            priority="high"))
    elif inp.screen_time > 5:
        recs.append(Recommendation(factor="High Screen Time",
            suggestion="Set a daily recreational screen budget of 2–3 hours. Use grayscale mode in the evening to reduce compulsive usage.",
            priority="medium"))

    if inp.marks_trend < -15:
        recs.append(Recommendation(factor="Sharp Grade Decline",
            suggestion="Your grades are declining significantly. Review your study strategy, identify weak subjects, and seek tutoring or office hours support.",
            priority="high"))
    elif inp.marks_trend < -5:
        recs.append(Recommendation(factor="Declining Performance",
            suggestion="Revisit your revision schedule. Spaced repetition and active recall are more effective than re-reading notes.",
            priority="medium"))

    if inp.study_hours < 1.5:
        recs.append(Recommendation(factor="Very Low Study Hours",
            suggestion="Under 1.5 hours of study per day is critically low. Even 3 focused daily sessions of 45 minutes will compound positively over weeks.",
            priority="high"))
    elif inp.study_hours < 3:
        recs.append(Recommendation(factor="Low Study Hours",
            suggestion="Try time-blocking: dedicate specific morning hours to studying. Consistency beats intensity.",
            priority="medium"))

    if inp.break_frequency < 1:
        recs.append(Recommendation(factor="No Study Breaks",
            suggestion="Working without breaks accelerates mental fatigue. Use the Pomodoro technique: 25-min focus, 5-min break, every cycle.",
            priority="medium"))

    if not recs:
        recs.append(Recommendation(factor="Healthy Patterns",
            suggestion="Your academic and lifestyle indicators look healthy. Maintain these habits and monitor stress during exam periods.",
            priority="low"))

    # Sort by priority
    order = {"high": 0, "medium": 1, "low": 2}
    recs.sort(key=lambda r: order.get(r.priority, 3))
    return recs[:6]


# ── Display names ─────────────────────────────────────────────────────────────
DISPLAY = {
    'study_hours':              'Study Hours / Day',
    'assignment_delay':         'Assignment Delay',
    'attendance_pct':           'Attendance %',
    'marks_trend':              'Marks Trend',
    'sleep_hours':              'Sleep Hours',
    'screen_time':              'Screen Time',
    'break_frequency':          'Break Frequency',
    'stress_level':             'Stress Level',
    'mood_score':               'Mood Score',
    'performance_drop_rate':    'Performance Drop Rate',
    'academic_pressure_index':  'Academic Pressure Index',
    'lifestyle_imbalance_score':'Lifestyle Imbalance Score',
}


# ── Endpoints ─────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"message": "BurnoutSense API v2", "status": "running"}


@app.get("/health")
def health():
    return {"status": "healthy", "model_loaded": model is not None}


@app.get("/model-metrics")
def get_model_metrics():
    if model_results is None:
        raise HTTPException(503, "Model not loaded")
    return {"metrics": model_results, "feature_importance": feature_importance}


@app.get("/feature-importance")
def get_feature_importance():
    if feature_importance is None:
        raise HTTPException(503, "Model not loaded")
    return {
        "feature_importance": {DISPLAY.get(k, k): v for k, v in feature_importance.items()}
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(inp: StudentInput):
    if model is None:
        raise HTTPException(503, "Model not loaded. Run ml_pipeline.py first.")

    derived = engineer_features(inp)

    fv = [
        inp.study_hours, inp.assignment_delay, inp.attendance_pct, inp.marks_trend,
        inp.sleep_hours, inp.screen_time, inp.break_frequency,
        inp.stress_level, inp.mood_score,
        derived['performance_drop_rate'],
        derived['academic_pressure_index'],
        derived['lifestyle_imbalance_score'],
    ]
    X = pd.DataFrame([fv], columns=feature_cols)

    # ── Model probability ────────────────────────────────────────────────────
    proba = model.predict_proba(X)[0]   # [p_low, p_med, p_high]
    probabilities = {
        "low":    round(float(proba[0]), 4),
        "medium": round(float(proba[1]), 4),
        "high":   round(float(proba[2]), 4),
    }

    # ── Burnout score: blend raw feature score + model confidence ────────────
    raw_score  = compute_raw_burnout_score(inp)
    model_score = float(proba[0] * 16 + proba[1] * 50 + proba[2] * 85)
    burnout_score = round(0.6 * raw_score + 0.4 * model_score, 1)

    if   burnout_score <= 33: risk_level, risk_color = "Low",    "#22c55e"
    elif burnout_score <= 66: risk_level, risk_color = "Medium", "#f59e0b"
    else:                      risk_level, risk_color = "High",   "#ef4444"

    # ── SHAP — per-instance, per-class ───────────────────────────────────────
    shap_exp   = explainer(X)                        # Explanation object
    shap_3d    = shap_exp.values                     # (1, n_features, n_classes)
    predicted_class = int(np.argmax(proba))

    # SHAP values for predicted class
    sv_pred  = shap_3d[0, :, predicted_class]        # shape (n_features,)
    # "Combined" signed importance: weighted over all classes
    sv_combo = (
        shap_3d[0, :, 0] * (-1) +    # low  → negative
        shap_3d[0, :, 1] * 0   +     # medium → neutral
        shap_3d[0, :, 2] * (+1)       # high  → positive
    )

    # Use predicted-class SHAPs for ranking; use combo for direction
    abs_importance = np.abs(sv_pred)
    max_imp = abs_importance.max() if abs_importance.max() > 0 else 1.0

    all_factors = []
    for i in range(len(feature_cols)):
        rel = abs_importance[i] / max_imp         # 0-1 relative importance
        direction = "increases" if sv_combo[i] > 0 else "decreases"
        impact = "High" if rel > 0.6 else "Medium" if rel > 0.25 else "Low"
        all_factors.append({
            "feature":      DISPLAY.get(feature_cols[i], feature_cols[i]),
            "feature_key":  feature_cols[i],
            "shap_value":   round(float(sv_pred[i]), 5),
            "shap_abs":     round(float(abs_importance[i]), 5),
            "relative_imp": round(float(rel), 4),
            "direction":    direction,
            "impact":       impact,
            "actual_value": round(float(fv[i]), 2),
        })

    all_factors.sort(key=lambda x: x["shap_abs"], reverse=True)
    top_factors = all_factors[:3]

    return PredictionResponse(
        burnout_score    = burnout_score,
        risk_level       = risk_level,
        risk_color       = risk_color,
        top_factors      = top_factors,
        all_shap_factors = all_factors,
        recommendations  = get_recommendations(inp),
        probabilities    = probabilities,
        derived_features = derived,
        input_summary    = {
            "stress_level":     inp.stress_level,
            "sleep_hours":      inp.sleep_hours,
            "mood_score":       inp.mood_score,
            "attendance_pct":   inp.attendance_pct,
            "assignment_delay": inp.assignment_delay,
            "study_hours":      inp.study_hours,
            "screen_time":      inp.screen_time,
        },
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
