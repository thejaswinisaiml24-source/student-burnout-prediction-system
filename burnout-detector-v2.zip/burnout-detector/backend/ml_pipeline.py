"""
Early Detection of Student Burnout - ML Pipeline (v2 - Fixed)
- Strong feature variance so predictions differ meaningfully across inputs
- Proper burnout score aligned with actual feature values
- Robust SHAP extraction for multi-output XGBoost
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import xgboost as xgb
import shap
import pickle
import json
import warnings
warnings.filterwarnings('ignore')

np.random.seed(42)


def generate_synthetic_dataset(n=2000):
    """
    Generate realistic student data with STRONG feature-label correlation.
    Each student is assigned a latent burnout tendency that drives all features,
    ensuring the model learns real separable patterns.
    """
    # Three student profiles: healthy (0), at-risk (1), burned-out (2)
    profile = np.random.choice([0, 1, 2], size=n, p=[0.40, 0.35, 0.25])

    rows = []
    for p in profile:
        if p == 0:  # Healthy
            study_hours       = np.clip(np.random.normal(6.5, 1.2), 3, 12)
            assignment_delay  = np.clip(np.random.exponential(0.8), 0, 4)
            attendance_pct    = np.clip(np.random.normal(90, 6), 70, 100)
            marks_trend       = np.clip(np.random.normal(8, 6), -5, 30)
            sleep_hours       = np.clip(np.random.normal(7.5, 0.8), 6, 10)
            screen_time       = np.clip(np.random.normal(2.5, 1.0), 0.5, 5)
            break_frequency   = np.clip(np.random.normal(5, 1.2), 2, 8)
            stress_level      = np.clip(np.random.normal(3.2, 1.0), 1, 6)
            mood_score        = np.clip(np.random.normal(7.8, 1.0), 5, 10)
        elif p == 1:  # At-risk
            study_hours       = np.clip(np.random.normal(4.2, 1.5), 1, 8)
            assignment_delay  = np.clip(np.random.exponential(2.5), 0, 8)
            attendance_pct    = np.clip(np.random.normal(74, 10), 50, 92)
            marks_trend       = np.clip(np.random.normal(-2, 8), -18, 15)
            sleep_hours       = np.clip(np.random.normal(6.0, 1.0), 4, 8)
            screen_time       = np.clip(np.random.normal(5.5, 1.5), 2, 9)
            break_frequency   = np.clip(np.random.normal(2.5, 1.2), 0, 6)
            stress_level      = np.clip(np.random.normal(6.5, 1.2), 4, 9)
            mood_score        = np.clip(np.random.normal(5.0, 1.2), 2, 7)
        else:  # Burned-out
            study_hours       = np.clip(np.random.normal(2.0, 1.2), 0, 5)
            assignment_delay  = np.clip(np.random.exponential(4.5), 2, 14)
            attendance_pct    = np.clip(np.random.normal(55, 12), 30, 78)
            marks_trend       = np.clip(np.random.normal(-14, 8), -30, 0)
            sleep_hours       = np.clip(np.random.normal(4.8, 1.0), 2, 7)
            screen_time       = np.clip(np.random.normal(8.5, 1.5), 5, 12)
            break_frequency   = np.clip(np.random.normal(1.0, 0.8), 0, 3)
            stress_level      = np.clip(np.random.normal(8.5, 1.0), 6, 10)
            mood_score        = np.clip(np.random.normal(2.8, 1.0), 1, 5)

        rows.append([study_hours, assignment_delay, attendance_pct, marks_trend,
                     sleep_hours, screen_time, break_frequency, stress_level, mood_score, p])

    df = pd.DataFrame(rows, columns=[
        'study_hours', 'assignment_delay', 'attendance_pct', 'marks_trend',
        'sleep_hours', 'screen_time', 'break_frequency',
        'stress_level', 'mood_score', 'true_label'
    ])

    # --- Derived features ---
    df['performance_drop_rate'] = np.clip(
        (30 - df['marks_trend']) / 60 * 50 +
        (100 - df['attendance_pct']) / 70 * 50,
        0, 100
    )

    df['academic_pressure_index'] = np.clip(
        df['assignment_delay'] / 14 * 40 +
        (12 - df['study_hours']) / 12 * 30 +
        df['stress_level'] / 10 * 30,
        0, 100
    )

    df['lifestyle_imbalance_score'] = np.clip(
        np.clip(8 - df['sleep_hours'], 0, 8) / 8 * 35 +
        df['screen_time'] / 12 * 30 +
        np.clip(8 - df['break_frequency'], 0, 8) / 8 * 35,
        0, 100
    )

    # Label = profile
    df['burnout_label'] = df['true_label'].astype(int)

    # Continuous burnout score for reference (0-100), derived from raw features
    df['burnout_score_raw'] = np.clip(
        df['stress_level'] / 10 * 22 +
        (10 - df['mood_score']) / 9 * 20 +
        np.clip(8 - df['sleep_hours'], 0, 6) / 6 * 14 +
        df['assignment_delay'] / 14 * 14 +
        (100 - df['attendance_pct']) / 70 * 12 +
        df['screen_time'] / 12 * 10 +
        (12 - df['study_hours']) / 12 * 8,
        0, 100
    )

    df.drop(columns=['true_label'], inplace=True)
    return df


def train_and_save_models(df):
    feature_cols = [
        'study_hours', 'assignment_delay', 'attendance_pct', 'marks_trend',
        'sleep_hours', 'screen_time', 'break_frequency',
        'stress_level', 'mood_score',
        'performance_drop_rate', 'academic_pressure_index', 'lifestyle_imbalance_score'
    ]

    X = df[feature_cols]
    y = df['burnout_label']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)

    results = {}

    # 1. Logistic Regression
    lr = LogisticRegression(max_iter=2000, multi_class='multinomial', C=1.0, random_state=42)
    lr.fit(X_train_scaled, y_train)
    y_pred_lr = lr.predict(X_test_scaled)
    results['logistic_regression'] = {
        'accuracy':  round(float(accuracy_score(y_test, y_pred_lr)), 4),
        'precision': round(float(precision_score(y_test, y_pred_lr, average='weighted', zero_division=0)), 4),
        'recall':    round(float(recall_score(y_test, y_pred_lr, average='weighted', zero_division=0)), 4),
        'f1':        round(float(f1_score(y_test, y_pred_lr, average='weighted', zero_division=0)), 4),
    }

    # 2. Random Forest
    rf = RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42, n_jobs=-1)
    rf.fit(X_train, y_train)
    y_pred_rf = rf.predict(X_test)
    results['random_forest'] = {
        'accuracy':  round(float(accuracy_score(y_test, y_pred_rf)), 4),
        'precision': round(float(precision_score(y_test, y_pred_rf, average='weighted', zero_division=0)), 4),
        'recall':    round(float(recall_score(y_test, y_pred_rf, average='weighted', zero_division=0)), 4),
        'f1':        round(float(f1_score(y_test, y_pred_rf, average='weighted', zero_division=0)), 4),
    }

    # 3. XGBoost with GridSearchCV
    param_grid = {
        'max_depth':     [4, 6],
        'learning_rate': [0.05, 0.1],
        'n_estimators':  [150, 300],
        'subsample':     [0.8, 1.0],
        'min_child_weight': [1, 3],
    }
    xgb_base = xgb.XGBClassifier(
        objective='multi:softprob',
        num_class=3,
        eval_metric='mlogloss',
        use_label_encoder=False,
        random_state=42,
        n_jobs=-1,
    )
    grid_search = GridSearchCV(xgb_base, param_grid, cv=5, scoring='f1_weighted', n_jobs=-1, verbose=0)
    grid_search.fit(X_train, y_train)

    best_xgb = grid_search.best_estimator_
    y_pred_xgb = best_xgb.predict(X_test)
    results['xgboost'] = {
        'accuracy':    round(float(accuracy_score(y_test, y_pred_xgb)), 4),
        'precision':   round(float(precision_score(y_test, y_pred_xgb, average='weighted', zero_division=0)), 4),
        'recall':      round(float(recall_score(y_test, y_pred_xgb, average='weighted', zero_division=0)), 4),
        'f1':          round(float(f1_score(y_test, y_pred_xgb, average='weighted', zero_division=0)), 4),
        'best_params': grid_search.best_params_,
    }

    print("\n=== MODEL RESULTS ===")
    for name, m in results.items():
        print(f"\n{name.upper()}")
        for k, v in m.items():
            if k != 'best_params':
                print(f"  {k}: {v:.4f}")

    # --- SHAP ---
    explainer = shap.TreeExplainer(best_xgb)
    shap_output = explainer(X_test)          # Explanation object (new API)
    # shap_output.values shape: (n_samples, n_features, n_classes)
    shap_vals_3d = shap_output.values        # numpy array

    # Global importance = mean |shap| over samples and classes
    mean_abs_shap = np.abs(shap_vals_3d).mean(axis=(0, 2))   # shape (n_features,)

    feature_importance = {
        feature_cols[i]: float(mean_abs_shap[i])
        for i in range(len(feature_cols))
    }
    feature_importance_sorted = dict(
        sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)
    )

    print("\n=== GLOBAL FEATURE IMPORTANCE (SHAP) ===")
    for feat, val in list(feature_importance_sorted.items())[:6]:
        print(f"  {feat}: {val:.4f}")

    # Persist
    with open('model.pkl', 'wb') as f:   pickle.dump(best_xgb, f)
    with open('scaler.pkl', 'wb') as f:  pickle.dump(scaler, f)
    with open('explainer.pkl', 'wb') as f: pickle.dump(explainer, f)
    with open('feature_cols.json', 'w') as f: json.dump(feature_cols, f)
    with open('model_results.json', 'w') as f: json.dump(results, f, indent=2)
    with open('feature_importance.json', 'w') as f: json.dump(feature_importance_sorted, f, indent=2)

    return best_xgb, scaler, explainer, feature_cols, results, feature_importance_sorted


if __name__ == '__main__':
    print("Generating student dataset …")
    df = generate_synthetic_dataset(2000)
    print(f"Shape: {df.shape}")
    print(f"Label distribution:\n{df['burnout_label'].value_counts().sort_index()}")

    print("\nTraining models …")
    train_and_save_models(df)
    print("\n✅ Done.")
